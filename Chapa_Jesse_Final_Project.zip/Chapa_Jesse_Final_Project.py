# Final Project – Data Snapshot Analyzer
# author: Jesse Chapa
# created: 2025-04-28  updated: 2025-05-10 (jc)
# Purpose: Load a CSV file, analyze data, and display basic statistics using a GUI
# CODING ASSISTANCE was used and is annotated
# Source used for statistical formula reference: https://realpython.com/python-statistics/

# pseudo code
# Display application title
# Initialize GUI window and layout elements
# Declare global variables: dataset, filename, upload_history
# Define function to load CSV file:
#     Prompt user to select a file
#     Load file using pandas
#     Show filename, row and column count
#     Store file in upload history
#     Enable Continue button
# Define function to show statistics:
#     Open new window
#     Display null values per column
#     Display mean, median, and mode for numeric columns
#     Add Load New File and Exit buttons
# Define function to show upload history:
#     Open new window
#     Display previously uploaded filenames
# Build main window with 4 buttons:
#     Upload CSV, Continue to Statistics, View Upload History, Exit
# Run GUI main loop

import tkinter as tk
from tkinter import filedialog, messagebox, PhotoImage
from PIL import Image, ImageTk
import pandas as pd
from statistics import mean, median, mode
import os

# Global variables used across functions
dataset = None         # Stores the loaded DataFrame
filename = ""          # Stores the current file name
upload_history = []    # Tracks the names of uploaded files during the session

# Function to load and validate a CSV file
# Prompts user for a file, reads it into a DataFrame, and updates the UI
# Parameters: none
# Returns: none

def load_csv_file():
    global dataset, filename
    filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if not filepath:
        return
    try:
        dataset = pd.read_csv(filepath) # Load CSV into DataFrame
        filename = os.path.basename(filepath)  # Extract base filename
        rows, cols = dataset.shape # Get shape info

        file_label.config(text=f"Loaded File: {filename}") # Update filename label
        size_label.config(text=f"Rows: {rows}, Columns: {cols}") # Update size label
        continue_btn.config(state=tk.NORMAL) # Enable statistics button

        # Add to history if new
        if filename not in upload_history:
            upload_history.append(filename)

    except Exception as e:
        messagebox.showerror("Error", f"Could not load file:\n{e}") # Error popup

# Function to display statistics from the CSV
# Opens a new window and shows null counts and basic numeric statistics
# Parameters: none
# Returns: none

def show_statistics():
    if dataset is None:
        return

    stats_win = tk.Toplevel(root) # Create new window for statistics
    stats_win.title("Statistics Overview")
    stats_win.geometry("600x500")

    text = tk.Text(stats_win, font=("Arial", 10)) # Area for displaying results
    text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    try:
        text.insert(tk.END, "Null Values per Column:\n")
        text.insert(tk.END, f"{dataset.isnull().sum()}\n\n")

        num_cols = dataset.select_dtypes(include='number') # Select numeric columns
        for col in num_cols.columns:
            values = num_cols[col].dropna()  # Drop missing values
            text.insert(
                tk.END,
                f"{col} -> Mean: {mean(values):.2f}, Median: {median(values):.2f}, Mode: {mode(values)}\n"
            )
    except Exception as e:
        text.insert(tk.END, f"Error generating statistics: {e}")

    # Buttons to close or reload
    btns = tk.Frame(stats_win)
    btns.pack(pady=10)
    tk.Button(btns, text="Load New File", command=lambda: [stats_win.destroy(), load_csv_file()]).pack(side=tk.LEFT, padx=10)
    tk.Button(btns, text="Exit", command=root.destroy).pack(side=tk.LEFT, padx=10)

# Function to display uploaded filenames
# Opens a small window with a listbox of uploaded files
# Parameters: none
# Returns: none

def show_upload_history():
    history_win = tk.Toplevel(root)  # New window for file history
    history_win.title("Upload History")
    history_win.geometry("400x300")

    tk.Label(history_win, text="Uploaded Files This Session:", font=("Arial", 12, "bold")).pack(pady=10)

    history_listbox = tk.Listbox(history_win, width=50, height=10)
    history_listbox.pack(padx=20, pady=5)

    for f in upload_history:
        history_listbox.insert(tk.END, f) # Display filenames

    tk.Button(history_win, text="Close", command=history_win.destroy).pack(pady=10)

# Main GUI Window setup
root = tk.Tk()
root.title("Data Snapshot Analyzer")
root.geometry("500x450")

# Display application title
tk.Label(root, text="📊 Data Snapshot Analyzer", font=("Arial", 16, "bold")).pack(pady=10)

# Display file name and size
file_label = tk.Label(root, text="No file selected.", font=("Arial", 12))
file_label.pack(pady=5)

size_label = tk.Label(root, text="", font=("Arial", 12))
size_label.pack(pady=5)

# Load and resize image assets
try:
    upload_img_raw = Image.open("upload_icon.png").resize((24, 24))  # Resize to 24x24 pixels
    stats_img_raw = Image.open("stats_icon.png").resize((24, 24))

    upload_img = ImageTk.PhotoImage(upload_img_raw)
    stats_img = ImageTk.PhotoImage(stats_img_raw)
except Exception as e:
    messagebox.showerror("Image Load Error", f"Could not load image: {e}")
    upload_img = None
    stats_img = None


# Buttons with images and alt-text labels
if upload_img:
    tk.Button(root, text="Upload CSV File", image=upload_img, compound="left", command=load_csv_file).pack(pady=10)
else:
    tk.Button(root, text="Upload CSV File", command=load_csv_file).pack(pady=10)

if stats_img:
    continue_btn = tk.Button(root, text="Continue to Statistics", image=stats_img, compound="left", state=tk.DISABLED, command=show_statistics)
    continue_btn.pack(pady=5)
else:
    continue_btn = tk.Button(root, text="Continue to Statistics", state=tk.DISABLED, command=show_statistics)
    continue_btn.pack(pady=5)

# Other standard buttons
tk.Button(root, text="View Upload History", command=show_upload_history).pack(pady=5)
tk.Button(root, text="Exit", command=root.destroy).pack(pady=10)
